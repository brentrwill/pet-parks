DROP SCHEMA IF EXISTS petpark;
CREATE SCHEMA petpark;
USE petpark;

CREATE TABLE contributor (
  contribution_date datetime(6) DEFAULT NULL,
  id bigint NOT NULL AUTO_INCREMENT,
  first_name varchar(255) DEFAULT NULL,
  last_name varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE pet (
  age int NOT NULL,
  id bigint NOT NULL AUTO_INCREMENT,
  bread_type varchar(255) DEFAULT NULL,
  name varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
);