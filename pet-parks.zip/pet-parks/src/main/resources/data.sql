INSERT INTO contributor (first_name, last_name, contribution_date) VALUES ('Bill', 'Smith', CurDate())
INSERT INTO contributor (first_name, last_name, contribution_date) VALUES ('Jenny', 'Miller', CurDate())
INSERT INTO contributor (first_name, last_name, contribution_date) VALUES ('Sam', 'Johnson', CurDate())
INSERT INTO contributor (first_name, last_name, contribution_date) VALUES ('Dave', 'Douglas', CurDate())
INSERT INTO contributor (first_name, last_name, contribution_date) VALUES ('Jose', 'Martinez', CurDate())
INSERT INTO contributor (first_name, last_name, contribution_date) VALUES ('Angelica', 'Perez', CurDate())

INSERT INTO pet (name, age, bread_type) VALUES ('Gracie', 3, 'Pug')