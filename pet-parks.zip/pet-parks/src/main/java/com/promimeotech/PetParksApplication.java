package com.promimeotech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetParksApplication {
	public static void main(String[] args) {
		SpringApplication.run(PetParksApplication.class, args);
	}
}
