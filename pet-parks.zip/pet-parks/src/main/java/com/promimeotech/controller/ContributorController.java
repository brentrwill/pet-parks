package com.promimeotech.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.promimeotech.controller.model.ContributorData;
import com.promimeotech.service.ContributorService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/contributor")
@Slf4j
public class ContributorController {

	@Autowired
	private ContributorService contributorService;
	private org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ContributorController.class);

	// HTTP GET
	@GetMapping("/{id}")
	public ContributorData getContributorById(@PathVariable Long id) {
		log.info("getContributorById {}");
		ContributorData contributor = contributorService.getContributorById(id);
		return contributor;
	}

	@GetMapping("/list")
	public List<ContributorData> listContributor() {
		log.info("listContributor {}");
		List<ContributorData> contributors = contributorService.getAllContributors();
		return contributors;
	}

	@PostMapping()
	public ContributorData createContributor(@RequestBody ContributorData data) {
		log.info("createContributor {}");
		ContributorData contributors = contributorService.saveContributor(data);
		return contributors;
	}

	@DeleteMapping("/{id}")
	public String deleteContributor(@PathVariable Long id) {
		log.info("deleteContributor {}");
		contributorService.deleteContributor(id);
		return "Ok";
	}
}
