package com.promimeotech.controller.model;

import com.promimeotech.entity.Pet;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PetData {
	private int age;
	private long id;
	private String breadType;
	private String name;

	public PetData(Pet pet) {
		this.id = pet.getId();
		this.age = pet.getAge();
		this.breadType = pet.getBreadType();
		this.name = pet.getName();
	}
}