package com.promimeotech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.promimeotech.controller.model.PetData;
import com.promimeotech.service.PetService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/pet")
@Slf4j
public class PetController {

	@Autowired
	private PetService petService;
	private org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(PetController.class);

	// HTTP GET
	@GetMapping("/{id}")
	public PetData getPetById(@PathVariable Long id) {
		log.info("getPetById {}");
		PetData petData = petService.getPetById(id);
		return petData;
	}

	// HTTP Post
	@PostMapping()
	public PetData createPet(@RequestBody PetData petData) {
		log.info("createPet {}");
		petData = petService.savePet(petData);
		return petData;
	}

	// HTTP DELETE
	@DeleteMapping("/{id}")
	public void deletePetById(@PathVariable Long id) {
		log.info("deletePetById {}");
		petService.deletePet(id);
	}
}
