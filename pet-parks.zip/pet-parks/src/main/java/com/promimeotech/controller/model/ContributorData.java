package com.promimeotech.controller.model;

import java.util.Date;

import com.promimeotech.entity.Contributor;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ContributorData {
	private long id;
	private String firstName;
	private String lastName;
	private Date contributionDate;

	public ContributorData(Contributor contrib) {
		this.id = contrib.getId();
		this.firstName = contrib.getFirstName();
		this.lastName = contrib.getLastName();
		this.contributionDate = contrib.getContributionDate();
	}
}
