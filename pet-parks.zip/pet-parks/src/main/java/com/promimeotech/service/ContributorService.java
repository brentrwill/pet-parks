package com.promimeotech.service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.promimeotech.controller.model.ContributorData;
import com.promimeotech.dao.ContributorDao;
import com.promimeotech.entity.Contributor;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ContributorService {

	@Autowired
	private ContributorDao contributorDao;
	private org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ContributorDao.class);

	public void deleteContributor(Long id) {
		contributorDao.deleteById(id);
	}

	public ContributorData saveContributor(ContributorData contributorData) {
		Contributor newContributor = copyContributorDataFields(contributorData);
		Contributor results = contributorDao.save(newContributor);
		if (results == null) {
			log.error("Unable to create a Conributor");
			// throw new NoSuchElementException("No Contributor found with Id : " + id);
		} else {
			contributorData = copyContributorFields(results);
			log.info("Contributor created : " + contributorData.getId());
		}
		return contributorData;
	}

	public ContributorData getContributorById(Long id) {
		ContributorData data = null;
		Optional<Contributor> results = contributorDao.findById(id);
		Contributor contrib = results.orElse(null);
		if (contrib == null) {
			log.error("No Contributor found with Id : " + id);
			throw new NoSuchElementException("No Contributor found with Id : " + id);
		} else {
			data = copyContributorFields(contrib);
			log.info("Contributor found with Id : " + id);
		}
		return data;
	}

	public List<ContributorData> getAllContributors() {
		List<ContributorData> data = new ArrayList<ContributorData>();
		List<Contributor> results = contributorDao.findAll();
		if (results == null || results.size() <= 0) {
			log.error("No Contributors where found.");
			throw new NoSuchElementException("No Contributors where found.");
		} else {
			for (Contributor contrib : results) {
				data.add(copyContributorFields(contrib));
			}
			log.info("Found list of Contributors : " + data.size());
		}
		return data;
	}

	private ContributorData copyContributorFields(Contributor contrib) {
		ContributorData data = new ContributorData(contrib);
		return data;
	}

	private Contributor copyContributorDataFields(ContributorData contribData) {
		Contributor data = new Contributor();
		data.setId(contribData.getId());
		data.setFirstName(contribData.getFirstName());
		data.setLastName(contribData.getLastName());
		data.setContributionDate(contribData.getContributionDate());

		return data;
	}
}
