package com.promimeotech.service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.promimeotech.controller.model.PetData;
import com.promimeotech.dao.PetDao;
import com.promimeotech.entity.Pet;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PetService {

	@Autowired
	private PetDao petDao;
	private org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(PetService.class);

	public void deletePet(Long id) {
		petDao.deleteById(id);
	}

	public PetData savePet(PetData PetData) {
		Pet newPet = copyPetDataFields(PetData);
		Pet results = petDao.save(newPet);
		if (results == null) {
			log.error("Unable to create a Conributor");
			// throw new NoSuchElementException("No Pet found with Id : " + id);
		} else {
			PetData = copyPetFields(results);
			log.info("Pet created : " + PetData.getId());
		}
		return PetData;
	}

	public PetData getPetById(Long id) {
		PetData data = null;
		Optional<Pet> results = petDao.findById(id);
		Pet contrib = results.orElse(null);
		if (contrib == null) {
			log.error("No Pet found with Id : " + id);
			throw new NoSuchElementException("No Pet found with Id : " + id);
		} else {
			data = copyPetFields(contrib);
			log.info("Pet found with Id : " + id);
		}
		return data;
	}

	public List<PetData> getAllPets() {
		List<PetData> data = new ArrayList<PetData>();
		List<Pet> results = petDao.findAll();
		if (results == null || results.size() <= 0) {
			log.error("No Pets where found.");
			throw new NoSuchElementException("No Pets where found.");
		} else {
			for (Pet contrib : results) {
				data.add(copyPetFields(contrib));
			}
			log.info("Found list of Pets : " + data.size());
		}
		return data;
	}

	private PetData copyPetFields(Pet pet) {
		PetData data = new PetData(pet);
		return data;
	}

	private Pet copyPetDataFields(PetData petData) {
		Pet data = new Pet();
		data.setId(petData.getId());
		data.setAge(petData.getAge());
		data.setBreadType(petData.getBreadType());
		data.setName(petData.getName());

		return data;
	}
}
