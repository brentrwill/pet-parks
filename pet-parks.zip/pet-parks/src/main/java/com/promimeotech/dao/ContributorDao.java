package com.promimeotech.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.promimeotech.entity.Contributor;

public interface ContributorDao extends JpaRepository<Contributor, Long>{
}