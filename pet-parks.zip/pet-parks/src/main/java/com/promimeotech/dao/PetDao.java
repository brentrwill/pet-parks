package com.promimeotech.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.promimeotech.entity.Pet;

public interface PetDao extends JpaRepository<Pet, Long> {
}